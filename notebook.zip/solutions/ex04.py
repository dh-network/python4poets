# Split the text by newline "\n"
lines = text.split("\n")

# Print the lines to check the result
lines
