# Create a list to save the nouns
nouns = []

# Iterate the tokens in the annotated text
# Check if the pos tag equals the noun tag
# If so, add the lemma to the noun list
for token in annotated_text:
    if token.pos_ == NOUN_TAG:
        nouns.append(token.lemma_)

# Count the nouns
noun_counts = Counter(nouns)

# Display the most common
print(noun_counts.most_common())
