# Count the words with the Counter from the
# collections library
counted_words = Counter(tokenized_clean)
print(counted_words)
