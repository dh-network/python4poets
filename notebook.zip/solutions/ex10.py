"""
Get the lemma
We need to put the underscore "_" after 
the lemma to get the string representation
"""

first_lemma = first_token.lemma_
print(first_lemma)


# Get the universal POS
first_pos = first_token.pos_
print(first_pos)

# Get the more fine grained STTS pos
first_pos_fine_grained = first_token.tag_
print(first_pos_fine_grained)
