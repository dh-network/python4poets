# Annotate your text
# Replace 'text' with your variable name
my_annotated_text = nlp(text)

# Get string representation
my_tokens = []
for token in my_annotated_text:
    my_tokens.append(token.text)

# Get the cleaned version of the tokens
# i.e. no punctuation or digits with the 
# string method .isalpha()
tokenized_clean = []
for word in my_tokens:
    if word.isalpha():
        tokenized_clean.append(word)
tokenized_clean[:20]
