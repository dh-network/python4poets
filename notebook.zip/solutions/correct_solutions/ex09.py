with open ("word_frequencies.txt", "w", encoding="utf-8") as file_out:
  for word, frequency in counted_words.most_common():
    file_out.writelines(f"{word},{frequency}\n")
