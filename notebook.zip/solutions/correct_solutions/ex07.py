counted_words = Counter(tokenized_clean)
