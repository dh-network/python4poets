nouns = []
for elem in annotated_text:
    if elem.pos_ == NOUN_TAG:
        nouns.append(elem.lemma_)
noun_counts = Counter(nouns)
for noun, freq in noun_counts.items():
    if freq >= 2:
        print(noun)