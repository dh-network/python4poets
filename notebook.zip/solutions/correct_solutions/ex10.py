first_lemma = first_token.lemma_
print(first_lemma)

# universal POS
first_pos = first_token.pos_
print(first_pos)

# more fine grained STTS pos
first_pos_fine_grained = first_token.tag_
print(first_pos_fine_grained)