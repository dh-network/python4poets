# Replace "text" with the variable name for your text
# Apply the Counter
my_counted_words = Counter(text)

# Acces of a word works just like for dictionaries
my_counted_words["that"]
