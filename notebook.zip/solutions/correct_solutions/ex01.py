# Append something to the value (a list) of Bobby
word_frequencies["Bobby"].append("cat")

# Print values of Bobby
print("Value of Bobby:", word_frequencies["Bobby"])

# Print the length of the values
print("Length of value of Bobby:", len(word_frequencies["Bobby"]))

# Add new key-value pair
word_frequencies["This"] = 3
print("After adding a new key-value pair:", word_frequencies)
