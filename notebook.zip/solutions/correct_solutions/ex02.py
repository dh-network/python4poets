# Split the string into words
tokenized_example = count_example.split()

# Create dictionary to save the result
word_frequencies = {}

# Loop over the words in the list
# At the first occurence, add the word with a count of 1
# at a second occurence (word is already in the dictionary) add 1 to the count (the value)
for token in tokenized_example:
    if token not in word_frequencies:
        word_frequencies[token] = 1
    else:
        # this is equivalent to: word_frequencies[token] = word_frequencies[token] + 1
        word_frequencies[token] += 1

print(word_frequencies)

# Other solutions:
# 1)
for token in tokenized_example:
    if token not in word_frequencies:
        word_frequencies[token] = 0
    word_frequencies[token] += 1

# 2)
for token in tokenized_example:
    if token in word_frequencies:
        word_frequencies[token] += 1
    else:
        word_frequencies[token] = 1

