path = "corpus/zen_of_python.txt"

with open (path, "r", encoding="utf-8") as file_in:
    to_process = file_in.read()