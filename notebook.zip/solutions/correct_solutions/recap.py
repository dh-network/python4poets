# Create a list
my_string = "A very nice string in double quotes to be split into tokens in a hacky way."

# Loop over characters
# Check if character is in the list of vowels
# We assume that a vowel list exists (somewhere in the notebook)

for character in my_string:
    if character == " ":
        words.append(single_word)
        single_word = ""
    else:
        single_word = single_word + character # This is equivalent to single_word += character

words.append(single_word)
print(words)

