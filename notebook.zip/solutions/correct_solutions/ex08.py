"""
We can either place our output filename directly
in the context manager dialogue ("my_freq_words.txt")
as in Variant A or save it to a variable first as in 
Variant B.
"""

# Variant A
with open("my_freq_words.txt", "w", encoding="utf-8") as file_out:
    for token, frequency in counted_words.most_common():
        file_out.write(token)

# Variant B
my_output_file_path = "my_freq_words.txt"
with open(my_output_file_path, "w", encoding="utf-8") as file_out:
    for token, frequency in counted_words.most_common():
        file_out.write(token)
