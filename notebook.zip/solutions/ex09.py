# Open the file "word_frequencies.csv" for writing ('w') 
# (we could have also saved the path to file/ file name in a variable)
with open ("word_frequencies.csv", "w", encoding="utf-8") as file_out:
    for word, frequency in counted_words.most_common():
        # Write the word and the frequency seperataed with comma
        file_out.write(f"{word},{frequency}\n")
