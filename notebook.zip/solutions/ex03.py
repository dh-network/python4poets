# Save the path to the input file in a variable
path = "corpus/zen_of_python.txt"

# Open the file with the context manager
# and read the file, saving the result to the "text" variable
with open (path, "r", encoding="utf-8") as file_in:
    text = file_in.read()
